AUTOTECH ATLAS · BMW INTERACTIVE ENGINEERING · v17.0

Contenuto:
- Galleria: rimosse le immagini generiche riutilizzate tra famiglie differenti. Le schede senza foto verificata mostrano la ricerca specifica BMW PressClub invece di attribuire immagini sbagliate.
- Laboratorio 3D interattivo: motore (architettura didattica parametrica), freni, trasmissione/differenziale e sospensioni. Rotazione mouse/touch, zoom, reset e selezione componenti.
- Il visualizzatore 3D usa Three.js e OrbitControls da CDN: richiede connessione internet e WebGL attivo.
- I modelli 3D sono ricostruzioni didattiche semplificate, non CAD OEM e non utilizzabili per manutenzione o quote di officina.

Pubblicazione: sostituire index.html nel repository GitHub e fare Commit su main. Vercel effettuerà il deploy automatico.
